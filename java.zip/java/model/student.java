/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author User
 */
public class student {

    String id;
    String name;
    String phonenumber;
    String email;
    String date;
    String password;

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getphone() {
        return phonenumber;
    }

    public String getemail() {
        return email;
    }
    
     public String getdate() {
        return date;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setphone(String phonenumber) {
        this.phonenumber = phonenumber;
    }

    public void setemail(String email) {
        this.email = email;
    }

     public void setdate(String date) {
        this.date = date;
    }
     public String getpassword() {
        return password;
    }
     public void setpassword(String password) {
        this.password = password;
    }
}
